import React from 'react';
import './list.scss';

const List = () => {
  return (
    <div className='home'>
        List
    </div>
  )
}

export default List