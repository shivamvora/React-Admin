import React from 'react';
import './single.scss';

const Single = () => {
  return (
    <div className='home'>
        Single
    </div>
  )
}

export default Single