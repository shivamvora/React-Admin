import React from 'react';
import './login.scss';

const Login = () => {
  return (
    <div className='home'>
        Login
    </div>
  )
}


export default Login;