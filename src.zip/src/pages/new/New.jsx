import React from 'react';
import './new.scss'


const New = () => {
  return (
    <div className='home'>
        New
    </div>
  )
}

export default New